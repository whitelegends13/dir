from django.shortcuts import render, HttpResponse
from store.models import Order
from google.cloud import bigquery, storage
from google.oauth2 import service_account
import os
import csv
from datetime import datetime

# Configurar las credenciales de autenticación de Google Cloud
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"D:\Descargas\digfact-urp-elbelarosa-16015675fe60.json"

class Reporte:
    def reporte(request):
        reporte = Order.objects.filter(status=True)
        suma = sum(item.price * item.quantity for item in reporte)
        contexto = {"reporte": reporte, 'suma': suma}
        return render(request, 'reporte.html', contexto)

    def create_csv(request):
        try:
            reporte = Order.objects.filter(status=True)
            total = len(reporte)
            time_file = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
            destinationcsv = f"ventas-{time_file}-tot{total}.csv"
            
            datos_csv = [['ID', 'Nombre', 'Cantidad', 'Precio', 'Estado', 'Ganancia_producto', 'Total']]
            for item in reporte:
                precio_cantidad = item.price * item.quantity
                total_producto = precio_cantidad
                datos_csv.append([item.id, item.product.name, item.quantity, item.price, item.status, precio_cantidad, total_producto])
            
            with open(destinationcsv, "w", encoding='UTF-8', newline='') as f:
                writer = csv.writer(f, quoting=csv.QUOTE_ALL)
                writer.writerows(datos_csv)
            
            bucket_name = 'lnd-urp-prueba2-bucket-bigquery03'
            source_file_name = destinationcsv
            destination_blob_name = destinationcsv
            
            upload_blob(bucket_name, source_file_name, destination_blob_name)
            
            project_id = 'digfact-urp-elbelarosa'
            dataset_name, table_name = get_new_dataset_table_name(project_id)
            
            create_dataset_if_not_exists(project_id, dataset_name)
            load_csv_to_bigquery(project_id, dataset_name, table_name, bucket_name, destination_blob_name)
            
            return HttpResponse("Archivo CSV subido y cargado en BigQuery correctamente.")
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=500)

def upload_blob(bucket_name, source_file_name, destination_blob_name):
    credentials_path = r"D:\Descargas\digfact-urp-elbelarosa-16015675fe60.json"
    credentials = service_account.Credentials.from_service_account_file(credentials_path)
    storage_client = storage.Client(credentials=credentials, project=credentials.project_id)
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(destination_blob_name)
    blob.upload_from_filename(source_file_name)
    print(f"Archivo {source_file_name} subido a {destination_blob_name}.")

def get_new_dataset_table_name(project_id):
    client = bigquery.Client()
    dataset_base_name = 'ventas_dataset'
    table_base_name = 'ventas_table'
    index = 1
    
    while True:
        dataset_name = f"{dataset_base_name}_{index:03d}"
        table_name = f"{table_base_name}_{index:03d}"
        dataset_id = f"{project_id}.{dataset_name}"
        table_id = f"{dataset_id}.{table_name}"
        
        try:
            client.get_dataset(dataset_id)
            client.get_table(table_id)
            index += 1
        except:
            break
    
    return dataset_name, table_name

def create_dataset_if_not_exists(project_id, dataset_name):
    client = bigquery.Client()
    dataset_id = f"{project_id}.{dataset_name}"
    
    try:
        client.get_dataset(dataset_id)
        print(f"Dataset {dataset_id} ya existe.")
    except:
        dataset = bigquery.Dataset(dataset_id)
        dataset.location = "US"
        client.create_dataset(dataset)
        print(f"Dataset {dataset_id} creado.")

def load_csv_to_bigquery(project_id, dataset_name, table_name, bucket_name, source_blob_name):
    client = bigquery.Client()
    dataset_ref = client.dataset(dataset_name)
    table_ref = dataset_ref.table(table_name)
    
    job_config = bigquery.LoadJobConfig()
    job_config.skip_leading_rows = 1
    job_config.source_format = bigquery.SourceFormat.CSV
    
    schema = [
        bigquery.SchemaField('ID', 'INTEGER'),
        bigquery.SchemaField('Nombre', 'STRING'),
        bigquery.SchemaField('Cantidad', 'INTEGER'),
        bigquery.SchemaField('Precio', 'FLOAT'),
        bigquery.SchemaField('Estado', 'BOOLEAN'),
        bigquery.SchemaField('Ganancia_producto', 'FLOAT'),
        bigquery.SchemaField('Total', 'FLOAT'),
    ]
    
    job_config.schema = schema
    
    uri = f"gs://{bucket_name}/{source_blob_name}"
    
    load_job = client.load_table_from_uri(uri, table_ref, job_config=job_config)
    
    load_job.result()
    
    print(f"Carga de datos desde {uri} a {dataset_name}.{table_name} completada.")
